import React from 'react';


class HelloWorld extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div>
                <h1>Hello, world!</h1>
            </div>
        )
    }
}

export default HelloWorld;