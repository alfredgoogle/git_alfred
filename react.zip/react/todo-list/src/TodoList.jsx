import React from 'react';


class TodoList extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div>
                <h1>Hello, world!</h1>
            </div>
        )
    }
}

export default TodoList;