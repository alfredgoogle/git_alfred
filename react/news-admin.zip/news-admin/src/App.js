import Route from './router/';


export default function App(props){

  return (
    <Route/>
  )
}